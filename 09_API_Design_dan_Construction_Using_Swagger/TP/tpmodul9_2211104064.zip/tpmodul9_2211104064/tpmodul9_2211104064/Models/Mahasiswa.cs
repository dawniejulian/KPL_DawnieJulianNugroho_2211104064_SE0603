﻿using System;
namespace tpmodul9_2211104064.Models
{
	public class Mahasiswa
	{
        public string Nama { get; set; }
        public string Nim { get; set; }
    }
}

