﻿using Microsoft.AspNetCore.Mvc;
using tpmodul9_2211104064.Models;
using System.Collections.Generic;

namespace tpmodul9_2211104064.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MahasiswaController : ControllerBase
    {
        private static List<Mahasiswa> daftarMahasiswa = new List<Mahasiswa>
        {
            new Mahasiswa { Nama = "Julian", Nim = "2211104064" },
            new Mahasiswa { Nama = "Fathur", Nim = "2211104070" },
            new Mahasiswa { Nama = "Samud", Nim = "2211104062" },
            new Mahasiswa { Nama = "Aditya sendi", Nim = "2211104067" },
            new Mahasiswa { Nama = "Dimas", Nim = "2211104086" }
        };

        // GET: api/mahasiswa
        [HttpGet]
        public ActionResult<IEnumerable<Mahasiswa>> GetAll()
        {
            return daftarMahasiswa;
        }

        // GET: api/mahasiswa/{index}
        [HttpGet("{index}")]
        public ActionResult<Mahasiswa> Get(int index)
        {
            if (index < 0 || index >= daftarMahasiswa.Count)
                return NotFound();
            return daftarMahasiswa[index];
        }

        // POST: api/mahasiswa
        [HttpPost]
        public ActionResult Add([FromBody] Mahasiswa mhs)
        {
            daftarMahasiswa.Add(mhs);
            return Ok(new { message = "Mahasiswa ditambahkan." });
        }

        // DELETE: api/mahasiswa/{index}
        [HttpDelete("{index}")]
        public ActionResult Delete(int index)
        {
            if (index < 0 || index >= daftarMahasiswa.Count)
                return NotFound();
            daftarMahasiswa.RemoveAt(index);
            return Ok(new { message = "Mahasiswa dihapus." });
        }
    }
}
