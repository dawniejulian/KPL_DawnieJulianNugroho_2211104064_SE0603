﻿namespace modul12_2211104064.Lib
{
    public class PangkatHelper
    {
        public static int CariNilaiPangkat(int a, int b)
        {
            if (b == 0) return 1;
            if (b < 0) return -1;
            if (b > 10 || a > 100) return -2;

            try
            {
                checked
                {
                    int result = 1;
                    for (int i = 0; i < b; i++)
                    {
                        result *= a;
                    }
                    return result;
                }
            }
            catch (OverflowException)
            {
                return -3;
            }
        }
    }
}
