﻿namespace modul12_2211104064.Lib;

public class Class1 {
}

