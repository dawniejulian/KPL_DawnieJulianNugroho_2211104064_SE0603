using AppKit;
using Foundation;

namespace modul12_2211104064
{
    [Register("AppDelegate")]
    public class AppDelegate : NSApplicationDelegate
    {
        MainWindow mainWindow;

        public override void DidFinishLaunching(NSNotification notification)
        {
            mainWindow = new MainWindow();
            mainWindow.MakeKeyAndOrderFront(null);
        }
    }
}
