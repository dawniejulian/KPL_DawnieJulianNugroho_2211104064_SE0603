﻿using System;
using AppKit;
using CoreGraphics;

namespace modul12_2211104064
{
    public class MainWindow : NSWindow
    {
        NSTextField inputA, inputB, outputLabel;
        NSButton hitungButton;

        public MainWindow() : base(new CGRect(200, 1000, 500, 300),
                                   NSWindowStyle.Titled,
                                   NSBackingStore.Buffered, false)
        {
            Title = "Cari Nilai Pangkat";
            InitializeComponents();
        }

        void InitializeComponents()
        {
            inputA = new NSTextField(new CGRect(20, 220, 200, 24)) { PlaceholderString = "Masukkan A" };
            inputB = new NSTextField(new CGRect(20, 180, 200, 24)) { PlaceholderString = "Masukkan B" };
            hitungButton = new NSButton(new CGRect(20, 140, 200, 32))
            {
                Title = "Hitung Pangkat",
                BezelStyle = NSBezelStyle.Rounded
            };
            outputLabel = new NSTextField(new CGRect(20, 100, 400, 24))
            {
                Editable = false,
                Bordered = false,
                DrawsBackground = false,
                StringValue = "Output akan tampil di sini."
            };

            hitungButton.Activated += (sender, e) =>
            {
                int a = int.Parse(inputA.StringValue);
                int b = int.Parse(inputB.StringValue);
                int hasil = CariNilaiPangkat(a, b);
                outputLabel.StringValue = $"Hasil: {hasil}";
            };

            ContentView.AddSubview(inputA);
            ContentView.AddSubview(inputB);
            ContentView.AddSubview(hitungButton);
            ContentView.AddSubview(outputLabel);
        }

        public int CariNilaiPangkat(int a, int b)
        {
            if (b == 0) return 1;
            if (b < 0) return -1;
            if (b > 10 || a > 100) return -2;

            try
            {
                checked
                {
                    int hasil = 1;
                    for (int i = 0; i < b; i++)
                    {
                        hasil *= a;
                    }
                    return hasil;
                }
            }
            catch (OverflowException)
            {
                return -3;
            }
        }
    }
}
