using modul12_2211104064;

// This is the main entry point of the application.
NSApplication.Init ();
NSApplication.Main (args);
