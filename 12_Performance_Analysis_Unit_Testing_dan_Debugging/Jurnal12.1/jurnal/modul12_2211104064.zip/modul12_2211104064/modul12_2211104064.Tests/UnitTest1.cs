﻿using Xunit;
using modul12_2211104064.Lib;

namespace modul12_2211104064.Tests
{
    public class PangkatHelperTests
    {
        [Fact]
        public void Test_Pangkat_2_3_Should_Return_8()
        {
            int result = PangkatHelper.CariNilaiPangkat(2, 3);
            Assert.Equal(8, result);
        }

        [Fact]
        public void Test_Pangkat_0_0_Should_Return_1()
        {
            int result = PangkatHelper.CariNilaiPangkat(0, 0);
            Assert.Equal(1, result);
        }

        [Fact]
        public void Test_B_Negative_Should_Return_Minus1()
        {
            int result = PangkatHelper.CariNilaiPangkat(2, -1);
            Assert.Equal(-1, result);
        }

        [Fact]
        public void Test_B_TooLarge_Should_Return_Minus2()
        {
            int result = PangkatHelper.CariNilaiPangkat(3, 11);
            Assert.Equal(-2, result);
        }
    }
}
